import spacy
import pdfplumber
import os
from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import joblib
import docx
import re
from django.core.files.storage import FileSystemStorage
from django.conf import settings

# Load the spaCy model for NER
nlp = spacy.load("en_core_web_sm")

# Load the trained model and TF-IDF vectorizer
model = joblib.load("C:/Users/Ali Computer/Downloads/LR_model.pkl")  # Adjust the path if needed
tfidf_vectorizer = joblib.load("C:/Users/Ali Computer/Downloads/tfidf_vectorizer.pkl")

# Helper function to extract text from PDF files using pdfplumber
def extract_text_from_pdf(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        text = ''
        for page in pdf.pages:
            text += page.extract_text()
    return text

# Helper function to extract text from DOCX files
# Helper function to extract text from DOCX files
def extract_text_from_docx(docx_path):
    # Get the absolute path of the file
    absolute_path = settings.MEDIA_ROOT / docx_path.name  # Use the filename directly from the 'Path' object
    doc = docx.Document(absolute_path)
    text = ''
    for para in doc.paragraphs:
        text += para.text
    return text


# Function to extract names using spaCy
def extract_names_from_text(text):
    doc = nlp(text)
    names = []
    
    # Extract entities labeled as PERSON (names of people)
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            if len(ent.text.split()) >= 2 and ent.text.istitle():
                names.append(ent.text)
    
    if names:
        return names[0]  # Return the first valid name found
    else:
        return None
# Helper function to extract email addresses from text using regex
# Helper function to extract the first email address from text
def extract_email_from_text(text):
    # Regular expression to match email addresses
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    emails = re.findall(email_pattern, text)
    return emails[0] if emails else None  # Return the first email, or None if no emails are found

# Preprocess the text using spaCy
def preprocess_text(text):
    # Convert text to lowercase
    text = text.lower()

    # Remove non-alphabetic characters (keep only letters and spaces)
    text = re.sub(r'[^a-z\s]', '', text)

    # Process the text with spaCy to create a Doc object
    doc = nlp(text)

    # Remove stopwords and lemmatize the tokens
    tokens = [token.lemma_ for token in doc if not token.is_stop and token.is_alpha]

    # Return the preprocessed text as a single string
    return ' '.join(tokens)

# Function to process the uploaded resumes
# Function to process the uploaded resumes
# Function to process the uploaded resumes
# Function to process the uploaded resumes
def process_files(uploaded_files):
    results = []
    
    for uploaded_file in uploaded_files:
        # Save file temporarily in the 'media' folder
        fs = FileSystemStorage(location=settings.MEDIA_ROOT)  # Store files in the 'media' folder
        filename = fs.save(uploaded_file.name, uploaded_file)  # Save the file
        file_path = fs.url(filename)  # Get the URL of the uploaded file
        
        # Use absolute path to read the file
        absolute_file_path = settings.MEDIA_ROOT / filename  # Get the absolute file path

        # Extract text based on file type (PDF, DOCX, etc.)
        if uploaded_file.name.endswith('.pdf'):
            text = extract_text_from_pdf(absolute_file_path)  # Use absolute file path to extract text
        elif uploaded_file.name.endswith('.docx'):
            text = extract_text_from_docx(absolute_file_path)  # Use absolute file path to extract text
        else:
            continue
        
        # Extract name from the text
        name = extract_names_from_text(text)

        # Extract email from the text
        email = extract_email_from_text(text)  # This will now return only the first email address

        # Preprocess and vectorize the text
        cleaned_text = preprocess_text(text)  # Ensure preprocess_text function is implemented
        vectorized_text = tfidf_vectorizer.transform([cleaned_text])
        
        # Predict the category (e.g., "REAL" or "FAKE")
        prediction = model.predict(vectorized_text)

        # Store the result
        results.append({
            'name': name,
            'email': email,  # Add the email to the results (only one email)
            'category': prediction[0],
            'file_url': file_path  # Add the file URL to the results for reference
        })
    
    return results



# View to handle the file upload and processing
def resume_upload(request):
    if request.method == 'POST' and request.FILES.getlist('resume_files'):
        uploaded_files = request.FILES.getlist('resume_files')  # Get the list of uploaded files
        results = process_files(uploaded_files)  # Process the files and get names and categories
        return render(request, 'upload_resume.html', {'results': results})
    return render(request, 'upload_resume.html')
