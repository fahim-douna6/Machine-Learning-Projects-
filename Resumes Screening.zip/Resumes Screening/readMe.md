# 📄 Resume Screening System using Machine Learning

This project implements an **automated resume classification system** that predicts the domain of a resume (e.g., Data Science, Web Development, HR, etc.) using Natural Language Processing (NLP) and Machine Learning.

---

## 🚀 Project Overview

Manually filtering hundreds of resumes is time-consuming for HR teams. This resume screening system automatically classifies resumes into relevant job categories using text analysis and classification models.

---

## 📁 Dataset

- **Source:** [Resume Dataset from Kaggle](https://www.kaggle.com/datasets/gauravduttakiit/resume-dataset)
- **Records:** 962 resumes
- **Fields:**
  - `Category` — Job domain (e.g., Python Developer, HR, Java Developer, etc.)
  - `Resume` — Text of the candidate's resume

---

## 🧠 Technologies Used

- Python
- Pandas, NumPy
- Scikit-learn
- TfidfVectorizer
- Logistic Regression / Naive Bayes / SVM
- NLTK (for stopwords, lemmatization)
- Streamlit (for UI – optional)

---

## 📊 Model Pipeline

1. **Text Cleaning**  
   - Remove punctuation, links, numbers, HTML tags, etc.
   - Lowercase, remove stopwords, lemmatize

2. **Feature Extraction**  
   - TF-IDF vectorization of cleaned resume text

3. **Model Training**  
   - Logistic Regression (baseline)
   - Optionally: MultinomialNB or LinearSVC

4. **Evaluation Metrics**  
   - Accuracy
   - Precision, Recall, F1-score
   - Cross-validation score (recommended to avoid overfitting)

---

## 📈 Sample Classification Report

```text
Accuracy: 0.99

Classification Report:
                 Data Science       1.00      1.00      1.00
                 Web Designing     1.00      1.00      1.00
                 HR                1.00      1.00      1.00
                 Python Developer  1.00      1.00      1.00
                 ...
