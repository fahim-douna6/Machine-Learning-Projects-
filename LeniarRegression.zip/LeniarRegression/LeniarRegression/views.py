from django.shortcuts import render
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression




def userinput(request):
    return render(request, 'userinput.html')
def viewpage(request):
    name = request.GET['name']
   

    

    dataset=pd.read_csv('C:/Users/mfahi/OneDrive/Desktop/Django Folder/LeniarRegression/Salary_Data.csv')
    X=dataset.iloc[:,:-1].values
    y=dataset.iloc[:,-1].values
    X_train, X_test, Y_train, Y_test = train_test_split(X, y, test_size=0.25, random_state=42)
    lr = LinearRegression()
    lr.fit(X_train, Y_train)
    
    yexp = int(request.GET['yxp'])
    Y_pred = lr.predict([[yexp]])
    data={
        'name':name,
        'prediction':Y_pred,
        'years':yexp
        

    }

    return render(request, 'viewpage.html',data)